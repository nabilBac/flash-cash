package controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class UserController {

    @GetMapping("/register")
    public String showRegistrationForm(Model model) {
        // Ajouter un attribut vide pour le champ email
        model.addAttribute("email", "");
        return "registration";
    }

    @PostMapping("/register")
    public String processRegistrationForm() {
        // Traiter les données du formulaire d'enregistrement
        // Enregistrer l'utilisateur dans la base de données
        // Rediriger vers la page de connexion
        return "redirect:/login";
    }

    @GetMapping("/login")
    public String showLoginForm(Model model) {
        // Ajouter un attribut vide pour le champ email
        model.addAttribute("email", "");
        return "login";
    }

    @PostMapping("/login")
    public String processLoginForm() {
        // Traiter les données du formulaire de connexion
        // Vérifier l'authentification de l'utilisateur
        // Rediriger vers la page d'accueil ou afficher un message d'erreur
        return "redirect:/dashboard";
    }
}
