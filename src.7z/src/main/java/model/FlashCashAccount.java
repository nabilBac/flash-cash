package model;

public class FlashCashAccount {
}
